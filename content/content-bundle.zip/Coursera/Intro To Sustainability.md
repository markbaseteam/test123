
## Week 1
### Sustainability and Population Growth
- The most common way to express this underlying idea about population damaging the environment is the so-called IPAT equation.
	- In this equation, I stands for the environmental impact, P stands for population, A stands for affluence, and T stands for technology.
- So what's wrong with IPAT?
- Well, firstly, it doesn't work if we try and extend it into the future.
	Because the equation assumes that all of the terms are independent, that is, population consumption and technology are unrelated to one another.
	P,A, and T, the terms on the IPAT equation are functions that are dependent on each other.
	it's very difficult to use when we apply it to the future.
- Secondly, two rigorous applications of the IPAT equation means that we discount the human experience.
- The IPAT equation makes us think that consumption and population are always wrong.
- Whereas in reality they may have a negative impact on the environment, in of itself they're positive things.
### Growth Curves
- This is the image of St. Matthew's Island which is in the Bering Sea which is off the coast of Alaska. In this lecture, we're going to be considering if human beings are more like reindeer or cells. We better hope we're more like cells. In 1944, 29 reindeer were introduced to the island which previously only had foxes and voles as resident mammals. 
- Can you guess what happened to the number of reindeer on the island? 
	- At first, the population exploded. The gray numbers are the data on which the red line is based. In 1963, 64 those are very harsh winter. Coincident with that, there was an enormous decline, in the number of reindeer. The reindeer had eaten all of the fodder available on the island so mass starvation followed. The population plummeted from around 6000 to just 42. By the 1980s, no reindeer were left. They never recovered from this over exploitation era. Clearly, we don't want to be like the reindeer. But not, everything has this reindeer growth curve. 
- Cells growing in isolation on a petri dish with a finite food source, don't grow exponentially. Because as their numbers increase the amount of food available decreases relative to their numbers and so their growth rate slows. These cell cultures both grew to a maximum size at a slowing rate as they approached this maximum population, this sustainable path.  And so, using these two as examples, ecologists would talk about there being different types of population growth curves.
- S shape growth curves are for systems that match the resources available. 
	- So they might grow quickly in the beginning but growth slows down as the carrying capacity, the amount of food available in the case of say, the reindeer on the island or the amount of food for the cells in the petri dish are exhausted. Imagine grass on a field for example. There is only a finite amount of sunlight. So even if there is no predators for grass, you know we have no grazing, there are no reindeer in this case. If we plant some grass in one corner, it will spread and grow, but it won't grow beyond a certain amount. It won't grow beyond the area that can be supported by the sunlight. Then this maximum population is known as the carrying capacity. So although the grass might grow quickly in the beginning, its
- growth will slow as it runs out of fresh open land to colonize. Other organisms, like the reindeer on the island can grow past this carrying capacity, at least for a short while. They do this by unsustainably using up resources. So they don't save some fodder for the next season. They eat everything that is available. Because this system is not in balance, it eventually crashes. You cannot have a population that goes beyond the carrying capacity indefinitely. Eventually it has to go back down or below the carrying capacity. Given that a system has a carrying capacity and for the purposes of our discussion, S shape growth might be considered sustainable, 
- J shape growth is clearly unsustainable. 
	- The problem for us, if we're thinking about is our growth curve sustainable, is that the two curves can look very similar for a very long time. So we might consider asking ourselves the question, is human society more like the reindeer or more like the cells in the petri dish? Some argue that we're already past the carrying capacity. So we're already destined for a big trough because we're in a J curve population growth or use growth or energy growth curve. 
- It's reasonable to think that we're near some kind of carrying capacity because: 
	- **around 38% of the world's land is currently already used for agricultural production. **
	- **population is very important. Because the population is showing a growth curve as we can see here. That is compatible with a J curve hypothesis and as we know, if we have a J curve**
	- **hypothesis, and it turns out to be true, we're headed for a big crash. We're unsustainable**.
- Malthus
	- Thomas Malthus thought that this kind of growth was not sustainable and he wrote down his reasoning in 1798.
	- Firstly, he noted that any population growth that was exponential, this means that it doubles in any given period of time.
	- Secondly, he assume that agricultural production was arithmetic, and its growth or geometric is enough. That is it increases with time in a straight line. So as you can see through the starter set, perhaps it starts out at two, and then we add two for every time step, so it goes to two, four, six, eight, 10.
		- Your two curves should look something like this, population increases at a greater and greater rate, it's exponential. While food production increases at a constant rate. 
- Now it turns out, that we did not have the sort of collapse that Malthus predicted over the last 200 years. But in defense of Malthus, his model was essentially correct up until the point of time in which he wrote it.
