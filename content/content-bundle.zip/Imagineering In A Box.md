## Exercise 1: Your Own Land
- Star Trek
- Based on the Star Trek universe
	- Future, science
		- Kind of like Epcot
	- Feeling
		- Happy
		- Optimistic future
		- Science
		- Engaged		
## Exercise 2: Theme
- Story
	- What's it about
		- Space Exploration
		- Utopia (a good world view)
		- Relationships
	- Lessons and Takeaways
		- Science and innovation can lead to improving the quality of life and the world in general
		- 
	- Emotions
		- Happiness
		- Optimism
            - 
### My Land
- How I Imagine being there
	- Peaceful
	- Fun
	- Engaged
	- 
- What I want guests to take away from their visit
	- That they can have an impact on the future
	- How to be optimistic
- 
## Exercise 3: Design
- 
